package pl.olczku.miniGames.randomizer.command;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import pl.olczku.miniGames.randomizer.game.RandomizerService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class StandaloneCommands {
    private StandaloneCommands() {}

    public static void register(JavaPlugin plugin, RandomizerService service) {
        var commandMap = plugin.getServer().getCommandMap();
        commandMap.register(plugin.getName().toLowerCase(Locale.ROOT), new PartyRootCommand(service));
        commandMap.register(plugin.getName().toLowerCase(Locale.ROOT), new LeaveRootCommand(service));
        Bukkit.getScheduler().runTask(plugin, () -> {
            try {
                plugin.getServer().getCommandMap();
            } catch (Exception ignored) {
            }
        });
    }

    private static final class PartyRootCommand extends Command {
        private final RandomizerService service;

        private PartyRootCommand(RandomizerService service) {
            super("party", "Komendy party", "/party", List.of("p"));
            this.service = service;
        }

        @Override
        public boolean execute(@NotNull CommandSender sender, @NotNull String label, @NotNull String[] args) {
            if (!(sender instanceof Player player)) return true;
            service.handlePartyCommand(player, args);
            return true;
        }

        @Override
        public @NotNull List<String> tabComplete(@NotNull CommandSender sender, @NotNull String alias, @NotNull String[] args) {
            if (!(sender instanceof Player player)) return List.of();
            if (args.length == 1) return filter(List.of("zapros", "dolacz", "odrzuc", "wyrzuc", "opusc", "lista", "lider", "pomoc"), args[0]);
            if (args.length == 2 && List.of("zapros", "dolacz", "wyrzuc", "lider").contains(args[0].toLowerCase(Locale.ROOT))) {
                List<String> names = new ArrayList<>();
                for (Player target : Bukkit.getOnlinePlayers()) if (!target.equals(player)) names.add(target.getName());
                return filter(names, args[1]);
            }
            return List.of();
        }
    }

    private static final class LeaveRootCommand extends Command {
        private final RandomizerService service;
        private LeaveRootCommand(RandomizerService service) { super("opusc", "Opuszcza Randomizer", "/opusc", List.of()); this.service = service; }
        @Override public boolean execute(@NotNull CommandSender sender, @NotNull String label, @NotNull String[] args) {
            if (sender instanceof Player player) service.leave(player);
            return true;
        }
    }

    private static List<String> filter(List<String> values, String typed) {
        String prefix = typed.toLowerCase(Locale.ROOT);
        return values.stream().filter(v -> v.toLowerCase(Locale.ROOT).startsWith(prefix)).sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }
}
